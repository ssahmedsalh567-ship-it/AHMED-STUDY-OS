package com.ahmed.studyos

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.LocalDate
import java.time.format.DateTimeFormatter

data class StudyTask(
    val id: Long,
    val title: String,
    val subject: String,
    val minutes: Int,
    val points: Int,
    val day: String,
    val done: Boolean = false,
    val proof: String = "",
    val carried: Boolean = false
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StudyOsApp(this) }
    }
}

private fun today() = LocalDate.now().toString()

private fun loadTasks(ctx: Context): MutableList<StudyTask> {
    val raw = ctx.getSharedPreferences("study_os", Context.MODE_PRIVATE).getString("tasks", "[]") ?: "[]"
    val arr = JSONArray(raw)
    val result = mutableListOf<StudyTask>()
    for (i in 0 until arr.length()) {
        val o = arr.getJSONObject(i)
        result.add(StudyTask(
            o.getLong("id"), o.getString("title"), o.optString("subject"),
            o.getInt("minutes"), o.getInt("points"), o.getString("day"),
            o.optBoolean("done"), o.optString("proof"), o.optBoolean("carried")
        ))
    }
    return result
}

private fun saveTasks(ctx: Context, tasks: List<StudyTask>) {
    val arr = JSONArray()
    tasks.forEach { t ->
        arr.put(JSONObject().apply {
            put("id", t.id); put("title", t.title); put("subject", t.subject)
            put("minutes", t.minutes); put("points", t.points); put("day", t.day)
            put("done", t.done); put("proof", t.proof); put("carried", t.carried)
        })
    }
    ctx.getSharedPreferences("study_os", Context.MODE_PRIVATE).edit().putString("tasks", arr.toString()).apply()
}

private fun copyProof(ctx: Context, uri: Uri): String? = try {
    val dir = File(ctx.filesDir, "proofs").apply { mkdirs() }
    val target = File(dir, "proof_${System.currentTimeMillis()}.jpg")
    ctx.contentResolver.openInputStream(uri)?.use { input ->
        target.outputStream().use { output -> input.copyTo(output) }
    }
    target.absolutePath
} catch (_: Exception) { null }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudyOsApp(ctx: Context) {
    val prefs = remember { ctx.getSharedPreferences("study_os", Context.MODE_PRIVATE) }
    var tasks by remember { mutableStateOf(loadTasks(ctx)) }
    var dark by remember { mutableStateOf(prefs.getBoolean("dark", true)) }
    var pin by remember { mutableStateOf(prefs.getString("pin", "") ?: "") }
    var unlocked by remember { mutableStateOf(pin.isEmpty()) }
    var pinEntry by remember { mutableStateOf("") }
    var settingPin by remember { mutableStateOf(pin.isEmpty()) }
    var newPin by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<StudyTask?>(null) }
    var remaining by remember { mutableIntStateOf(0) }
    var running by remember { mutableStateOf(false) }
    var paused by remember { mutableStateOf(false) }
    var showAdd by remember { mutableStateOf(false) }
    var showReview by remember { mutableStateOf(false) }
    var title by remember { mutableStateOf("") }
    var subject by remember { mutableStateOf("عام") }
    var mins by remember { mutableStateOf("30") }
    var pts by remember { mutableStateOf("10") }
    var reviewIds by remember { mutableStateOf(setOf<Long>()) }

    val todayTasks = tasks.filter { it.day == today() }
    val completed = todayTasks.count { it.done }
    val pending = todayTasks.filter { !it.done }
    val lost = pending.sumOf { it.points }
    val score = (100 - lost).coerceAtLeast(0)

    fun persist(updated: List<StudyTask>) {
        tasks = updated.toMutableList()
        saveTasks(ctx, updated)
    }

    LaunchedEffect(running, paused, selected?.id) {
        while (running && !paused && remaining > 0) {
            delay(1000)
            remaining -= 1
        }
        if (running && remaining <= 0) {
            running = false
        }
    }

    MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            if (!unlocked) {
                PinScreen(pinEntry, { pinEntry = it }, {
                    if (it == pin) { unlocked = true; pinEntry = "" }
                })
            } else if (settingPin) {
                PinSetupScreen(newPin, { newPin = it }, {
                    if (newPin.length >= 4) {
                        pin = newPin
                        prefs.edit().putString("pin", pin).apply()
                        settingPin = false
                        unlocked = true
                    }
                })
            } else {
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = { Text("AHMED STUDY OS", fontWeight = FontWeight.Bold) },
                        actions = {
                            IconButton(onClick = {
                                dark = !dark
                                prefs.edit().putBoolean("dark", dark).apply()
                            }) { Icon(if (dark) Icons.Default.LightMode else Icons.Default.DarkMode, "المظهر") }
                            IconButton(onClick = { unlocked = false }) { Icon(Icons.Default.Lock, "قفل") }
                        }
                    )
                },
                floatingActionButton = {
                    FloatingActionButton(onClick = { showAdd = true }) {
                        Icon(Icons.Default.Add, "إضافة مهمة")
                    }
                }
            ) { padding ->
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(vertical = 12.dp)
                ) {
                    item {
                        Card(shape = RoundedCornerShape(22.dp)) {
                            Column(Modifier.fillMaxWidth().padding(18.dp)) {
                                Text(LocalDate.now().format(DateTimeFormatter.ofPattern("dd / MM / yyyy")), style = MaterialTheme.typography.labelLarge)
                                Spacer(Modifier.height(8.dp))
                                Text("$score / 100", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                                Text("درجة إنجاز اليوم")
                                Spacer(Modifier.height(12.dp))
                                LinearProgressIndicator(progress = { completed.toFloat() / (todayTasks.size.coerceAtLeast(1)) }, modifier = Modifier.fillMaxWidth())
                                Spacer(Modifier.height(8.dp))
                                Text("مكتمل: $completed  •  متبقي: ${pending.size}")
                                Text("الوقت المخطط: ${todayTasks.sumOf { it.minutes }} دقيقة")
                            }
                        }
                    }
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text("مهام اليوم", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            TextButton(onClick = { showReview = true }) { Text("مراجعة اليوم") }
                        }
                    }
                    if (todayTasks.isEmpty()) {
                        item { Text("لا توجد مهام اليوم. اضغط + لإضافة أول مهمة.") }
                    }
                    items(todayTasks, key = { it.id }) { task ->
                        TaskCard(task, onStart = {
                            selected = task
                            remaining = task.minutes * 60
                            running = false
                            paused = false
                        })
                    }
                    if (selected != null) {
                        item {
                            FocusCard(
                                task = selected!!,
                                remaining = remaining,
                                running = running,
                                paused = paused,
                                onStart = { if (remaining == 0) remaining = selected!!.minutes * 60; running = true; paused = false },
                                onPause = { paused = true },
                                onResume = { paused = false; running = true },
                                onCancel = { running = false; selected = null },
                                onProof = { path ->
                                    val t = selected!!
                                    persist(tasks.map { if (it.id == t.id) it.copy(done = true, proof = path) else it })
                                    running = false
                                    selected = null
                                },
                                ctx = ctx
                            )
                        }
                    }
                    item {
                        OutlinedButton(onClick = { showReview = true }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.AssignmentTurnedIn, null)
                            Spacer(Modifier.width(8.dp))
                            Text("إغلاق اليوم ومراجعة المهام")
                        }
                    }
                }
            }
            if (showAdd) {
                AlertDialog(
                    onDismissRequest = { showAdd = false },
                    title = { Text("مهمة جديدة") },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(title, { title = it }, label = { Text("اسم المهمة") }, singleLine = true)
                            OutlinedTextField(subject, { subject = it }, label = { Text("المادة") }, singleLine = true)
                            OutlinedTextField(mins, { mins = it.filter(Char::isDigit) }, label = { Text("المدة بالدقائق") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                            OutlinedTextField(pts, { pts = it.filter(Char::isDigit) }, label = { Text("النقاط المخصومة عند عدم الإنجاز") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            val m = mins.toIntOrNull() ?: 30
                            val p = pts.toIntOrNull() ?: 10
                            if (title.isNotBlank() && m > 0 && p >= 0) {
                                persist(tasks + StudyTask(System.currentTimeMillis(), title.trim(), subject.trim(), m, p, today()))
                                title = ""; showAdd = false
                            }
                        }) { Text("إضافة") }
                    },
                    dismissButton = { TextButton(onClick = { showAdd = false }) { Text("إلغاء") } }
                )
            }
            if (showReview) {
                AlertDialog(
                    onDismissRequest = { showReview = false },
                    title = { Text("مراجعة مهام اليوم") },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("الدرجة الحالية: $score / 100")
                            Text("حدد المهام غير المكتملة التي تريد ترحيلها إلى الغد:")
                            pending.forEach { task ->
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Checkbox(checked = reviewIds.contains(task.id), onCheckedChange = {
                                        reviewIds = if (it) reviewIds + task.id else reviewIds - task.id
                                    })
                                    Column {
                                        Text(task.title)
                                        Text("${task.minutes} دقيقة • ${task.points} نقطة", style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                            }
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            val tomorrow = LocalDate.now().plusDays(1).toString()
                            persist(tasks.map { t ->
                                if (reviewIds.contains(t.id) && t.day == today() && !t.done) t.copy(day = tomorrow, carried = true) else t
                            })
                            reviewIds = emptySet()
                            showReview = false
                        }) { Text("ترحيل المحدد") }
                    },
                    dismissButton = { TextButton(onClick = { showReview = false }) { Text("إغلاق") } }
                )
            }
            }
        }
    }
}

@Composable
fun TaskCard(task: StudyTask, onStart: () -> Unit) {
    Card(shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(task.title, fontWeight = FontWeight.Bold)
                Text("${task.subject} • ${task.minutes} دقيقة • ${task.points} نقطة", style = MaterialTheme.typography.bodySmall)
                if (task.carried) Text("مُرحّلة من يوم سابق", color = MaterialTheme.colorScheme.tertiary, style = MaterialTheme.typography.labelSmall)
                if (task.done) Text("مكتملة ✓", color = MaterialTheme.colorScheme.primary)
            }
            if (!task.done) Button(onClick = onStart) { Text("ابدأ") }
        }
    }
}

@Composable
fun FocusCard(
    task: StudyTask, remaining: Int, running: Boolean, paused: Boolean,
    onStart: () -> Unit, onPause: () -> Unit, onResume: () -> Unit,
    onCancel: () -> Unit, onProof: (String) -> Unit, ctx: Context
) {
    var proofPath by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) copyProof(ctx, uri)?.let { proofPath = it }
    }
    Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
        Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("وضع التركيز", style = MaterialTheme.typography.titleMedium)
            Text(task.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            val time = "%02d:%02d".format(remaining / 60, remaining % 60)
            Text(time, style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Bold)
            if (remaining == 0 && !running) {
                Text("انتهى الوقت. ارفع صورة لإثبات إنجاز المهمة.")
                OutlinedButton(onClick = { picker.launch("image/*") }) {
                    Icon(Icons.Default.AddAPhoto, null); Spacer(Modifier.width(6.dp)); Text(if (proofPath.isBlank()) "اختيار صورة الإثبات" else "تم اختيار الصورة")
                }
                Button(onClick = { if (proofPath.isNotBlank()) onProof(proofPath) }, enabled = proofPath.isNotBlank(), modifier = Modifier.fillMaxWidth()) {
                    Text("تأكيد إكمال المهمة")
                }
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (!running) Button(onClick = onStart) { Text("ابدأ") }
                    else if (paused) Button(onClick = onResume) { Text("استكمال") }
                    else Button(onClick = onPause) { Text("إيقاف مؤقت") }
                    OutlinedButton(onClick = onCancel) { Text("إنهاء الجلسة") }
                }
            }
        }
    }
}

@Composable
fun PinScreen(value: String, onValue: (String) -> Unit, onUnlock: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text("AHMED STUDY OS", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("أدخل رقم PIN")
        OutlinedTextField(value, onValue, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), label = { Text("PIN") })
        Button(onClick = { onUnlock(value) }, modifier = Modifier.fillMaxWidth()) { Text("دخول") }
    }
}

@Composable
fun PinSetupScreen(value: String, onValue: (String) -> Unit, onSave: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text("إنشاء رقم PIN", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("اختر رقمًا من 4 أرقام أو أكثر لحماية فتح التطبيق.")
        OutlinedTextField(value, onValue, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), label = { Text("PIN جديد") })
        Button(onClick = onSave, enabled = value.length >= 4, modifier = Modifier.fillMaxWidth()) { Text("حفظ الرقم") }
    }
}
