package com.ahmed.studyos

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.app.NotificationManager
import androidx.core.app.NotificationCompat

class StudyReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra("title") ?: "مهمة مذاكرة"
        val subject = intent.getStringExtra("subject") ?: ""
        val notification = NotificationCompat.Builder(context, "study_reminders")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("موعد المذاكرة اقترب")
            .setContentText("$title${if (subject.isNotBlank()) " • $subject" else ""} — متبقي 10 دقائق")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()
        context.getSystemService(NotificationManager::class.java).notify((title + subject).hashCode(), notification)
    }
}
