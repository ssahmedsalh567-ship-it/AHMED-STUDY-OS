package com.ahmed.studyos

import android.content.Context
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.time.format.DateTimeParseException
import java.time.DayOfWeek
import java.time.format.DateTimeFormatter

data class StudyTask(
    val id: Long,
    val title: String,
    val subject: String,
    val minutes: Int,
    val points: Int,
    val day: String,
    val done: Boolean = false,
    val proof: String = "",
    val carried: Boolean = false,
    val dueTime: String = ""
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createStudyNotificationChannel(this)
        rescheduleSavedTaskReminders(this)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 7001)
        }
        setContent { StudyOsApp(this) }
    }
}

private fun today() = LocalDate.now().toString()

private const val STUDY_CHANNEL_ID = "study_reminders"

private fun createStudyNotificationChannel(ctx: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val channel = android.app.NotificationChannel(STUDY_CHANNEL_ID, "تذكيرات المذاكرة", android.app.NotificationManager.IMPORTANCE_DEFAULT)
        ctx.getSystemService(android.app.NotificationManager::class.java).createNotificationChannel(channel)
    }
}

private fun reminderPendingIntent(ctx: Context, task: StudyTask): PendingIntent =
    PendingIntent.getBroadcast(
        ctx, task.id.hashCode(),
        Intent(ctx, StudyReminderReceiver::class.java).apply {
            putExtra("title", task.title)
            putExtra("subject", task.subject)
        },
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

private fun cancelTaskReminder(ctx: Context, task: StudyTask) {
    val alarm = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    alarm.cancel(reminderPendingIntent(ctx, task))
}

private fun scheduleTaskReminder(ctx: Context, task: StudyTask) {
    if (task.done || task.dueTime.isBlank()) {
        cancelTaskReminder(ctx, task)
        return
    }
    try {
        val time = LocalTime.parse(task.dueTime)
        val remindAt = LocalDate.parse(task.day).atTime(time).minusMinutes(10)
        if (!remindAt.isAfter(LocalDateTime.now())) {
            cancelTaskReminder(ctx, task)
            return
        }
        val alarm = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarm.setAndAllowWhileIdle(
            AlarmManager.RTC_WAKEUP,
            remindAt.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli(),
            reminderPendingIntent(ctx, task)
        )
    } catch (_: Exception) { }
}

private fun rescheduleSavedTaskReminders(ctx: Context) {
    val raw = ctx.getSharedPreferences("study_os", Context.MODE_PRIVATE)
        .getString("tasks", "[]") ?: "[]"
    runCatching {
        val array = JSONArray(raw)
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            val task = StudyTask(
                id = obj.getLong("id"), title = obj.getString("title"),
                subject = obj.optString("subject"), minutes = obj.optInt("minutes", 30),
                points = obj.optInt("points", 10), day = obj.getString("day"),
                done = obj.optBoolean("done"), proof = obj.optString("proof"),
                carried = obj.optBoolean("carried"), dueTime = obj.optString("dueTime")
            )
            scheduleTaskReminder(ctx, task)
        }
    }
}

/** First-run study plan: 4 focused hours per day, excluding lesson attendance. */
private fun createDefaultWeekTasks(): MutableList<StudyTask> {
    // The user's study week runs Saturday through Friday.
    val todayDate = LocalDate.now()
    val daysSinceSaturday = (todayDate.dayOfWeek.value + 1) % 7
    val weekStart = todayDate.minusDays(daysSinceSaturday.toLong())
    val plan = mapOf(
        DayOfWeek.SATURDAY to listOf(
            Triple("مراجعة وتدريبات رياضيات", "رياضيات", 90),
            Triple("فهم ومراجعة الكيمياء", "كيمياء", 90),
            Triple("كلمات وقواعد إنجليزي", "إنجليزي", 60)
        ),
        DayOfWeek.SUNDAY to listOf(
            Triple("فهم درس وحل مسائل", "فيزياء", 120),
            Triple("نحو وتطبيقات", "عربي", 120)
        ),
        DayOfWeek.MONDAY to listOf(
            Triple("مفردات وقواعد وتدريب", "إنجليزي", 60),
            Triple("مراجعة الكيمياء وحل", "كيمياء", 60),
            Triple("حل مسائل رياضيات", "رياضيات", 120)
        ),
        DayOfWeek.TUESDAY to listOf(
            Triple("تدريبات رياضيات", "رياضيات", 90),
            Triple("مسائل وتطبيقات كيمياء", "كيمياء", 90),
            Triple("مراجعة قوانين الفيزياء", "فيزياء", 60)
        ),
        DayOfWeek.WEDNESDAY to listOf(
            Triple("حل مسائل فيزياء", "فيزياء", 90),
            Triple("أدب ونحو", "عربي", 90),
            Triple("قراءة وتدريب إنجليزي", "إنجليزي", 60)
        ),
        DayOfWeek.THURSDAY to listOf(
            Triple("مراجعة إنجليزي", "إنجليزي", 60),
            Triple("حل واجب الكيمياء", "كيمياء", 60),
            Triple("تدريبات رياضيات متنوعة", "رياضيات", 120)
        ),
        DayOfWeek.FRIDAY to listOf(
            Triple("مراجعة أسبوعية فيزياء", "فيزياء", 60),
            Triple("مراجعة عربي", "عربي", 60),
            Triple("مراجعة رياضيات", "رياضيات", 60),
            Triple("مراجعة إنجليزي وكيمياء", "إنجليزي وكيمياء", 60)
        )
    )
    val result = mutableListOf<StudyTask>()
    for (offset in 0L..6L) {
        val date = weekStart.plusDays(offset)
        val blocks = plan[date.dayOfWeek].orEmpty()
        blocks.forEachIndexed { index, block ->
            result.add(StudyTask(
                id = date.toEpochDay() * 100 + index + 1,
                title = block.first,
                subject = block.second,
                minutes = block.third,
                points = 10,
                day = date.toString()
            ))
        }
    }
    return result
}

private fun loadTasks(ctx: Context): MutableList<StudyTask> {
    val raw = ctx.getSharedPreferences("study_os", Context.MODE_PRIVATE).getString("tasks", "[]") ?: "[]"
    val arr = JSONArray(raw)
    val result = mutableListOf<StudyTask>()
    for (i in 0 until arr.length()) {
        val o = arr.getJSONObject(i)
        result.add(StudyTask(
            o.getLong("id"), o.getString("title"), o.optString("subject"),
            o.getInt("minutes"), o.getInt("points"), o.getString("day"),
            o.optBoolean("done"), o.optString("proof"), o.optBoolean("carried"), o.optString("dueTime")
        ))
    }
    return result
}

private fun saveTasks(ctx: Context, tasks: List<StudyTask>) {
    val arr = JSONArray()
    tasks.forEach { t ->
        arr.put(JSONObject().apply {
            put("id", t.id); put("title", t.title); put("subject", t.subject)
            put("minutes", t.minutes); put("points", t.points); put("day", t.day)
            put("done", t.done); put("proof", t.proof); put("carried", t.carried); put("dueTime", t.dueTime)
        })
    }
    ctx.getSharedPreferences("study_os", Context.MODE_PRIVATE).edit().putString("tasks", arr.toString()).apply()
}

private fun copyProof(ctx: Context, uri: Uri): String? = try {
    val dir = File(ctx.filesDir, "proofs").apply { mkdirs() }
    val target = File(dir, "proof_${System.currentTimeMillis()}.jpg")
    ctx.contentResolver.openInputStream(uri)?.use { input ->
        target.outputStream().use { output -> input.copyTo(output) }
    }
    target.absolutePath
} catch (_: Exception) { null }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudyOsApp(ctx: Context) {
    val prefs = remember { ctx.getSharedPreferences("study_os", Context.MODE_PRIVATE) }
    var tasks by remember {
        mutableStateOf(loadTasks(ctx).let { existing ->
            if (existing.isEmpty() && !prefs.getBoolean("default_week_created", false)) {
                val starter = createDefaultWeekTasks()
                saveTasks(ctx, starter)
                prefs.edit().putBoolean("default_week_created", true).apply()
                starter
            } else existing
        })
    }
    var showSplash by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) { delay(1800); showSplash = false }
    var dark by remember { mutableStateOf(prefs.getBoolean("dark", true)) }
    var selectedPage by remember { mutableStateOf("الرئيسية") }
    var drawerOpen by remember { mutableStateOf(false) }
    var pin by remember { mutableStateOf(prefs.getString("pin", "") ?: "") }
    var unlocked by remember { mutableStateOf(pin.isEmpty()) }
    var pinEntry by remember { mutableStateOf("") }
    var settingPin by remember { mutableStateOf(pin.isEmpty()) }
    var newPin by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<StudyTask?>(null) }
    var remaining by remember { mutableIntStateOf(0) }
    var running by remember { mutableStateOf(false) }
    var paused by remember { mutableStateOf(false) }
    var showAdd by remember { mutableStateOf(false) }
    var showReview by remember { mutableStateOf(false) }
    var title by remember { mutableStateOf("") }
    var subject by remember { mutableStateOf("عام") }
    var mins by remember { mutableStateOf("30") }
    var pts by remember { mutableStateOf("10") }
    var dueTime by remember { mutableStateOf("09:00") }
    var reviewIds by remember { mutableStateOf(setOf<Long>()) }
    var prayers by remember { mutableStateOf(prefs.getStringSet("prayers_${today()}", emptySet()) ?: emptySet()) }
    var quranDone by remember { mutableStateOf(prefs.getBoolean("quran_${today()}", false)) }
    var reports by remember { mutableStateOf(prefs.getString("daily_reports", "[]") ?: "[]") }

    val todayTasks = tasks.filter { it.day == today() }
    val completed = todayTasks.count { it.done }
    val pending = todayTasks.filter { !it.done }
    val score = todayTasks.filter { it.done }.sumOf { it.points }

    fun persist(updated: List<StudyTask>) {
        tasks = updated.toMutableList()
        saveTasks(ctx, updated)
        updated.forEach { scheduleTaskReminder(ctx, it) }
    }

    LaunchedEffect(running, paused, selected?.id) {
        while (running && !paused && remaining > 0) {
            delay(1000)
            remaining -= 1
        }
        if (running && remaining <= 0) {
            running = false
        }
    }

    MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            if (showSplash) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    androidx.compose.foundation.Image(
                        painter = painterResource(id = com.ahmed.studyos.R.drawable.study_splash),
                        contentDescription = "شاشة افتتاحية AHMED STUDY OS",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }
            } else if (!unlocked) {
                PinScreen(pinEntry, { pinEntry = it }, {
                    if (it == pin) { unlocked = true; pinEntry = "" }
                })
            } else if (settingPin) {
                PinSetupScreen(newPin, { newPin = it }, {
                    if (newPin.length >= 4) {
                        pin = newPin
                        prefs.edit().putString("pin", pin).apply()
                        settingPin = false
                        unlocked = true
                    }
                })
            } else {
            Scaffold(
                bottomBar = {
                    NavigationBar {
                        listOf(
                            "الرئيسية" to Icons.Default.Home,
                            "الجدول" to Icons.Default.CalendarMonth,
                            "التركيز" to Icons.Default.Timer,
                            "العبادات" to Icons.Default.Favorite,
                            "التقارير" to Icons.Default.Assessment,
                            "الإعدادات" to Icons.Default.Settings
                        ).forEach { (label, icon) ->
                            NavigationBarItem(
                                selected = selectedPage == label,
                                onClick = { selectedPage = label },
                                icon = { Icon(icon, contentDescription = label) },
                                label = { Text(label) },
                                alwaysShowLabel = false
                            )
                        }
                    }
                },
                topBar = {
                    TopAppBar(
                        title = { Text("AHMED STUDY OS", fontWeight = FontWeight.Bold) },
                        navigationIcon = {
                            IconButton(onClick = { drawerOpen = !drawerOpen }) {
                                Icon(Icons.Default.Menu, contentDescription = "القائمة")
                            }
                        },
                        actions = {
                            IconButton(onClick = {
                                dark = !dark
                                prefs.edit().putBoolean("dark", dark).apply()
                            }) { Icon(if (dark) Icons.Default.LightMode else Icons.Default.DarkMode, "المظهر") }
                            IconButton(onClick = { unlocked = false }) { Icon(Icons.Default.Lock, "قفل") }
                        }
                    )
                },
                floatingActionButton = {
                    FloatingActionButton(onClick = { showAdd = true }) {
                        Icon(Icons.Default.Add, "إضافة مهمة")
                    }
                }
            ) { padding ->
                if (drawerOpen) {
                    AlertDialog(
                        onDismissRequest = { drawerOpen = false },
                        title = { Text("قائمة AHMED STUDY OS") },
                        text = {
                            Column {
                                listOf("الرئيسية", "الجدول", "التركيز", "العبادات", "التقارير", "الأرشيف", "الإعدادات").forEach { page ->
                                    TextButton(onClick = { selectedPage = page; drawerOpen = false }, modifier = Modifier.fillMaxWidth()) { Text(page) }
                                }
                            }
                        },
                        confirmButton = { TextButton(onClick = { drawerOpen = false }) { Text("إغلاق") } }
                    )
                }
                if (selectedPage == "الرئيسية") {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(vertical = 12.dp)
                ) {
                    item {
                        Card(shape = RoundedCornerShape(22.dp)) {
                            Column(Modifier.fillMaxWidth().padding(18.dp)) {
                                Text(LocalDate.now().format(DateTimeFormatter.ofPattern("dd / MM / yyyy")), style = MaterialTheme.typography.labelLarge)
                                Spacer(Modifier.height(8.dp))
                                Text("$score نقطة", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                                Text("النقاط المكتسبة اليوم")
                                Spacer(Modifier.height(12.dp))
                                LinearProgressIndicator(progress = { completed.toFloat() / (todayTasks.size.coerceAtLeast(1)) }, modifier = Modifier.fillMaxWidth())
                                Spacer(Modifier.height(8.dp))
                                Text("مكتمل: $completed  •  متبقي: ${pending.size}")
                                Text("الوقت المخطط: ${todayTasks.sumOf { it.minutes }} دقيقة")
                            }
                        }
                    }
                    item {
                        Card(
                            shape = RoundedCornerShape(22.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)
                        ) {
                            Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("آية اليوم", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Text("وَقُل رَّبِّ زِدْنِي عِلْمًا", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                                Text("طه: ١١٤", style = MaterialTheme.typography.labelMedium)
                                Text("ابدأ بخطوة ثابتة، فالتقدم يأتي بالاستمرار.", style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text("مهام اليوم", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            TextButton(onClick = { showReview = true }) { Text("مراجعة اليوم") }
                        }
                    }
                    if (todayTasks.isEmpty()) {
                        item { Text("لا توجد مهام اليوم. اضغط + لإضافة أول مهمة.") }
                    }
                    items(todayTasks, key = { it.id }) { task ->
                        TaskCard(task, onStart = {
                            selected = task
                            remaining = task.minutes * 60
                            running = false
                            paused = false
                        })
                    }
                    if (selected != null) {
                        item {
                            FocusCard(
                                task = selected!!,
                                remaining = remaining,
                                running = running,
                                paused = paused,
                                onStart = { if (remaining == 0) remaining = selected!!.minutes * 60; running = true; paused = false },
                                onPause = { paused = true },
                                onResume = { paused = false; running = true },
                                onCancel = { running = false; selected = null },
                                onProof = { path ->
                                    val t = selected!!
                                    persist(tasks.map { if (it.id == t.id) it.copy(done = true, proof = path) else it })
                                    running = false
                                    selected = null
                                },
                                ctx = ctx
                            )
                        }
                    }
                    item {
                        OutlinedButton(onClick = { showReview = true }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.AssignmentTurnedIn, null)
                            Spacer(Modifier.width(8.dp))
                            Text("إغلاق اليوم ومراجعة المهام")
                        }
                    }
                    item {
                        Card(shape = RoundedCornerShape(22.dp)) {
                            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("جدول الحصص والخطة الأسبوعية", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                Text("هدف المذاكرة: ٤ ساعات يوميًا بخلاف الحصص", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                                Text("تم تجهيز مهام أسبوعية مبدئية تلقائيًا؛ يمكنك تعديلها أو إضافة مهامك من زر +.", style = MaterialTheme.typography.bodySmall)
                                val schedule = listOf(
                                    "السبت" to "9:30 رياضيات • 5:30 كيمياء • 8:00 رياضيات",
                                    "الأحد" to "7:30 فيزياء • 2:30 عربي",
                                    "الاثنين" to "10:00 إنجليزي • 12:00 كيمياء • 3:00 رياضيات",
                                    "الثلاثاء" to "9:30 رياضيات • 5:30 كيمياء • 8:00 رياضيات",
                                    "الأربعاء" to "7:30 فيزياء • 2:30 عربي",
                                    "الخميس" to "10:00 إنجليزي • 12:00 كيمياء • 3:00 رياضيات • 8:00 رياضيات",
                                    "الجمعة" to "مراجعة أسبوعية وتعويض"
                                )
                                schedule.forEach { (day, lessons) ->
                                    Column {
                                        Text(day, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                        Text(lessons, style = MaterialTheme.typography.bodyMedium)
                                    }
                                    HorizontalDivider()
                                }
                            }
                        }
                    }
                    item {
                        Card(shape = RoundedCornerShape(22.dp)) {
                            Column(Modifier.fillMaxWidth().padding(16.dp)) {
                                Text("متابعة العبادات", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                Text("متابعة مستقلة عن نقاط المذاكرة")
                                listOf("الفجر", "الظهر", "العصر", "المغرب", "العشاء").forEach { prayer ->
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Checkbox(checked = prayers.contains(prayer), onCheckedChange = { checked ->
                                            prayers = if (checked) prayers + prayer else prayers - prayer
                                            prefs.edit().putStringSet("prayers_${today()}", prayers).apply()
                                        })
                                        Text(prayer)
                                    }
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Checkbox(checked = quranDone, onCheckedChange = {
                                        quranDone = it
                                        prefs.edit().putBoolean("quran_${today()}", it).apply()
                                    })
                                    Text("إنجاز الورد القرآني اليومي")
                                }
                            }
                        }
                    }
                    item {
                        Card(shape = RoundedCornerShape(22.dp)) {
                            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("ملخص اليوم", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                Text("المهام المكتملة: $completed من ${todayTasks.size}")
                                Text("نسبة الإنجاز: ${if (todayTasks.isEmpty()) 0 else completed * 100 / todayTasks.size}%")
                                Text("النقاط المكتسبة: $score")
                                Text("العبادات المسجلة: ${prayers.size} من 5 • الورد القرآني: ${if (quranDone) "مكتمل" else "لم يُسجل بعد"}")
                            }
                        }
                    }
                }
                } else {
                    StudyPage(
                        page = selectedPage,
                        tasks = tasks,
                        prayers = prayers,
                        quranDone = quranDone,
                        reports = reports,
                        dark = dark,
                        onPrayerChange = { prayer, checked ->
                            prayers = if (checked) prayers + prayer else prayers - prayer
                            prefs.edit().putStringSet("prayers_${today()}", prayers).apply()
                        },
                        onQuranChange = { done ->
                            quranDone = done
                            prefs.edit().putBoolean("quran_${today()}", done).apply()
                        },
                        onThemeChange = { enabled -> dark = enabled; prefs.edit().putBoolean("dark", enabled).apply() },
                        modifier = Modifier.fillMaxSize().padding(padding)
                    )
                }
            }
            if (showAdd) {
                AlertDialog(
                    onDismissRequest = { showAdd = false },
                    title = { Text("مهمة جديدة") },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(title, { title = it }, label = { Text("اسم المهمة") }, singleLine = true)
                            OutlinedTextField(subject, { subject = it }, label = { Text("المادة") }, singleLine = true)
                            OutlinedTextField(mins, { mins = it.filter(Char::isDigit) }, label = { Text("المدة بالدقائق") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                            OutlinedTextField(pts, { pts = it.filter(Char::isDigit) }, label = { Text("النقاط المكتسبة عند الإنجاز") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                            OutlinedTextField(dueTime, { dueTime = it }, label = { Text("موعد المهمة (ساعة:دقيقة مثل 09:30)") }, singleLine = true)
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            val m = mins.toIntOrNull() ?: 30
                            val p = pts.toIntOrNull() ?: 10
                            if (title.isNotBlank() && m > 0 && p >= 0) {
                                val newTask = StudyTask(System.currentTimeMillis(), title.trim(), subject.trim(), m, p, today(), dueTime = dueTime.trim())
                                persist(tasks + newTask)
                                scheduleTaskReminder(ctx, newTask)
                                title = ""; dueTime = "09:00"; showAdd = false
                            }
                        }) { Text("إضافة") }
                    },
                    dismissButton = { TextButton(onClick = { showAdd = false }) { Text("إلغاء") } }
                )
            }
            if (showReview) {
                AlertDialog(
                    onDismissRequest = { showReview = false },
                    title = { Text("مراجعة مهام اليوم") },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("النقاط المكتسبة اليوم: $score")
                            Text("المهام غير المكتملة التالية ستُوزّع تلقائيًا على الأيام المتبقية من الأسبوع:")
                            pending.forEach { task ->
                                Column {
                                    Text(task.title, fontWeight = FontWeight.SemiBold)
                                    Text("${task.minutes} دقيقة • ${task.points} نقطة عند الإنجاز", style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            val dayTasks = tasks.filter { it.day == today() }
                            val doneTasks = dayTasks.filter { it.done }
                            val unfinished = dayTasks.filter { !it.done }
                            val percent = if (dayTasks.isEmpty()) 0 else doneTasks.size * 100 / dayTasks.size
                            val report = JSONObject().apply {
                                put("date", today())
                                put("completed", doneTasks.size)
                                put("total", dayTasks.size)
                                put("percent", percent)
                                put("points", doneTasks.sumOf { it.points })
                                put("pending", unfinished.size)
                                put("message", if (percent >= 80) "أداء ممتاز، حافظ على الاستمرار." else "راجع ما أنجزته، وابدأ غدًا بخطوة منظمة.")
                            }
                            val reportArray = JSONArray(reports)
                            if ((0 until reportArray.length()).none { reportArray.getJSONObject(it).optString("date") == today() }) reportArray.put(report)
                            reports = reportArray.toString()
                            prefs.edit().putString("daily_reports", reports).apply()
                            // Distribute every unfinished task over the remaining days
                            // of the Saturday-Friday study week. If today is Friday,
                            // continue into the next Saturday instead of losing tasks.
                            val todayDate = LocalDate.now()
                            val daysUntilFriday = (DayOfWeek.FRIDAY.value - todayDate.dayOfWeek.value + 7) % 7
                            val daysToUse = if (daysUntilFriday == 0) 7 else daysUntilFriday
                            val availableDays = (1L..daysToUse.toLong()).map { todayDate.plusDays(it) }
                            val redistributed = tasks.toMutableList()
                            unfinished.forEachIndexed { index, task ->
                                val targetDay = availableDays[index % availableDays.size].toString()
                                val taskIndex = redistributed.indexOfFirst { it.id == task.id }
                                if (taskIndex >= 0) {
                                    redistributed[taskIndex] = task.copy(day = targetDay, carried = true)
                                }
                            }
                            persist(redistributed)
                            reviewIds = emptySet()
                            showReview = false
                        }) { Text("حفظ تقرير اليوم وتوزيع المتبقي تلقائيًا") }
                    },
                    dismissButton = { TextButton(onClick = { showReview = false }) { Text("إغلاق") } }
                )
            }
            }
        }
    }
}

@Composable
fun StudyPage(
    page: String,
    tasks: List<StudyTask>,
    prayers: Set<String>,
    quranDone: Boolean,
    reports: String,
    dark: Boolean,
    onPrayerChange: (String, Boolean) -> Unit,
    onQuranChange: (Boolean) -> Unit,
    onThemeChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val todayTasks = tasks.filter { it.day == today() }
    val completed = todayTasks.count { it.done }
    val points = todayTasks.filter { it.done }.sumOf { it.points }
    LazyColumn(modifier = modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(vertical = 16.dp)) {
        item {
            Text(page, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("AHMED STUDY OS • نظامك الدراسي الشخصي", color = MaterialTheme.colorScheme.primary)
        }
        when (page) {
            "الجدول" -> {
                item { InfoCard("جدول الحصص الأسبوعي", "السبت والثلاثاء: 9:30 رياضيات، 5:30 كيمياء، 8:00 رياضيات\nالأحد والأربعاء: 7:30 فيزياء، 2:30 عربي\nالاثنين: 10:00 إنجليزي، 12:00 كيمياء، 3:00 رياضيات\nالخميس: 10:00 إنجليزي، 12:00 كيمياء، 3:00 رياضيات، 8:00 رياضيات\nالجمعة: مراجعة أسبوعية") }
                item { InfoCard("مهام اليوم", "${todayTasks.size} مهمة • المكتمل $completed • النقاط $points") }
                items(todayTasks, key = { it.id }) { task -> TaskCard(task) {} }
            }
            "التركيز" -> item { InfoCard("مركز التركيز", "ابدأ جلسة المذاكرة من الصفحة الرئيسية بالضغط على زر «ابدأ» بجوار المهمة. المؤقت يتابع الوقت ويطلب صورة إثبات قبل تسجيل الإنجاز.") }
            "العبادات" -> {
                item { InfoCard("متابعة الصلوات", "متابعة مستقلة تمامًا عن نقاط الدراسة") }
                items(listOf("الفجر", "الظهر", "العصر", "المغرب", "العشاء")) { prayer ->
                    Card { Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Checkbox(checked = prayers.contains(prayer), onCheckedChange = { onPrayerChange(prayer, it) }); Text(prayer) } }
                }
                item { Card { Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Checkbox(checked = quranDone, onCheckedChange = onQuranChange); Text("الورد القرآني اليومي") } } }
            }
            "التقارير" -> {
                val todayDate = LocalDate.now()
                val daysSinceSaturday = (todayDate.dayOfWeek.value + 1) % 7
                val weekStart = todayDate.minusDays(daysSinceSaturday.toLong())
                val weekEnd = weekStart.plusDays(6)
                val weekTasks = tasks.filter {
                    runCatching {
                        val taskDate = LocalDate.parse(it.day)
                        !taskDate.isBefore(weekStart) && !taskDate.isAfter(weekEnd)
                    }.getOrDefault(false)
                }
                val weekCompleted = weekTasks.count { it.done }
                val weekPoints = weekTasks.filter { it.done }.sumOf { it.points }
                val weekPercent = if (weekTasks.isEmpty()) 0 else weekCompleted * 100 / weekTasks.size
                item {
                    InfoCard(
                        "التقرير الأسبوعي • السبت إلى الجمعة",
                        "الفترة: ${weekStart.format(DateTimeFormatter.ofPattern("dd/MM"))} إلى ${weekEnd.format(DateTimeFormatter.ofPattern("dd/MM"))}\n" +
                            "المهام المكتملة: $weekCompleted من ${weekTasks.size}\n" +
                            "نسبة الإنجاز: $weekPercent%\n" +
                            "النقاط المكتسبة: $weekPoints\n" +
                            "المهام المتبقية: ${weekTasks.count { !it.done }}"
                    )
                }
                item { InfoCard("ملخص اليوم", "المهام المكتملة: $completed من ${todayTasks.size}\nنسبة الإنجاز: ${if (todayTasks.isEmpty()) 0 else completed * 100 / todayTasks.size}%\nالنقاط المكتسبة: $points") }
                val savedReports = remember(reports) { runCatching { JSONArray(reports) }.getOrElse { JSONArray() } }
                if (savedReports.length() == 0) item { InfoCard("أرشيف التقارير", "لم يتم حفظ تقرير يومي بعد. استخدم زر إغلاق اليوم من الصفحة الرئيسية لحفظ التقرير وتوزيع المهام المتبقية تلقائيًا.") }
                items((0 until savedReports.length()).map { savedReports.getJSONObject(it) }.reversed()) { report ->
                    InfoCard("تقرير ${report.optString("date")}", "الإنجاز: ${report.optInt("completed")} من ${report.optInt("total")} (${report.optInt("percent")}%)\nالنقاط: ${report.optInt("points")}\nالمهام المرحلة: ${report.optInt("pending")}\n${report.optString("message")}")
                }
            }
            "الأرشيف" -> {
                item { InfoCard("أرشيف المهام", "إجمالي المهام المحفوظة: ${tasks.size}") }
                items(tasks.sortedByDescending { it.id }, key = { it.id }) { task -> TaskCard(task) {} }
            }
            "الإعدادات" -> {
                item { Card { Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Text("الوضع الداكن", Modifier.weight(1f)); Switch(checked = dark, onCheckedChange = onThemeChange) } } }
                item { InfoCard("الحماية", "يمكن قفل التطبيق من رمز القفل أعلى الشاشة. يتم إعداد رقم PIN عند أول تشغيل.") }
            }
        }
    }
}

@Composable
fun InfoCard(title: String, body: String) {
    Card(shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(body, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
fun TaskCard(task: StudyTask, onStart: () -> Unit) {
    Card(shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(task.title, fontWeight = FontWeight.Bold)
                Text("${task.subject} • ${task.minutes} دقيقة • ${task.points} نقطة", style = MaterialTheme.typography.bodySmall)
                if (task.carried) Text("مُرحّلة من يوم سابق", color = MaterialTheme.colorScheme.tertiary, style = MaterialTheme.typography.labelSmall)
                if (task.done) Text("مكتملة ✓", color = MaterialTheme.colorScheme.primary)
            }
            if (!task.done) Button(onClick = onStart) { Text("ابدأ") }
        }
    }
}

@Composable
fun FocusCard(
    task: StudyTask, remaining: Int, running: Boolean, paused: Boolean,
    onStart: () -> Unit, onPause: () -> Unit, onResume: () -> Unit,
    onCancel: () -> Unit, onProof: (String) -> Unit, ctx: Context
) {
    var proofPath by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) copyProof(ctx, uri)?.let { proofPath = it }
    }
    Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
        Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("وضع التركيز", style = MaterialTheme.typography.titleMedium)
            Text(task.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            val time = "%02d:%02d".format(remaining / 60, remaining % 60)
            Text(time, style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Bold)
            if (remaining == 0 && !running) {
                Text("انتهى الوقت. ارفع صورة لإثبات إنجاز المهمة.")
                OutlinedButton(onClick = { picker.launch("image/*") }) {
                    Icon(Icons.Default.AddAPhoto, null); Spacer(Modifier.width(6.dp)); Text(if (proofPath.isBlank()) "اختيار صورة الإثبات" else "تم اختيار الصورة")
                }
                Button(onClick = { if (proofPath.isNotBlank()) onProof(proofPath) }, enabled = proofPath.isNotBlank(), modifier = Modifier.fillMaxWidth()) {
                    Text("تأكيد إكمال المهمة")
                }
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (!running) Button(onClick = onStart) { Text("ابدأ") }
                    else if (paused) Button(onClick = onResume) { Text("استكمال") }
                    else Button(onClick = onPause) { Text("إيقاف مؤقت") }
                    OutlinedButton(onClick = onCancel) { Text("إنهاء الجلسة") }
                }
            }
        }
    }
}

@Composable
fun PinScreen(value: String, onValue: (String) -> Unit, onUnlock: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text("AHMED STUDY OS", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("أدخل رقم PIN")
        OutlinedTextField(value, onValue, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), label = { Text("PIN") })
        Button(onClick = { onUnlock(value) }, modifier = Modifier.fillMaxWidth()) { Text("دخول") }
    }
}

@Composable
fun PinSetupScreen(value: String, onValue: (String) -> Unit, onSave: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text("إنشاء رقم PIN", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("اختر رقمًا من 4 أرقام أو أكثر لحماية فتح التطبيق.")
        OutlinedTextField(value, onValue, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), label = { Text("PIN جديد") })
        Button(onClick = onSave, enabled = value.length >= 4, modifier = Modifier.fillMaxWidth()) { Text("حفظ الرقم") }
    }
}
